  "data size %d not supported",ERROR,
  "value from %ld to %ld required",ERROR,
  "register expected",ERROR,

  "data size %d not supported",ERROR,
  "operand doesn't fit into 8-bits",ERROR,
  "branch destination out of range",ERROR,
